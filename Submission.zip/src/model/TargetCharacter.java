package model;

/**
 * Helper class to build target character.
 */

public class TargetCharacter {
  private int health;
  private final String name;
  private int characterPositionIndex;
  private final int numRooms;

  /**
   * Constructor for target character.
   * 
   * @param healthIn health of target.
   * @param nameIn   name of target.
   * @param numRoomsIn the number of rooms.
   */

  public TargetCharacter(int healthIn, String nameIn, int numRoomsIn) {
    this.health = healthIn;
    this.name = nameIn;
    this.numRooms = numRoomsIn;
    this.characterPositionIndex = 0;
  }

  public int getHealth() {
    return health;
  }

  public void setHealth(int healthIn) {
    this.health = healthIn;
  }

  public String getName() {
    return name;
  }

  public int getCharacterPositionIndex() {
    return characterPositionIndex;
  }

  public int getNumRooms() {
    return numRooms;
  }

  /**
   * moves character forward by 1 room.
   */

  public void move() {

    if (characterPositionIndex > numRooms - 1) {

      characterPositionIndex = 0;
    }

    characterPositionIndex += 1;

  }

  /**
   * reduces the health by damage.
   * 
   * @param damage - this is the damage caused.
   */
  public void takeDamage(int damage) {

    int damageVal = health - damage;
    setHealth(damageVal);

  }

}
